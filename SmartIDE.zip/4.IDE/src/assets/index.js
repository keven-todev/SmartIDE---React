import html from "./html.svg"
import css from "./css.svg"
import js from "./js.svg"


export {html, css, js}